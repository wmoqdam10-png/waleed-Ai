package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Event Horizon Black Hole Color Palette
val CosmicVoid = Color(0xFF05020A)
val EventHorizonDark = Color(0xFF0F081F)
val SurfaceCard = Color(0xFF130A2B)
val SurfaceCardBorder = Color(0x3300F5D4)

val SingularityPurple = Color(0xFF9D4EDD)
val AccretionCyan = Color(0xFF00F5D4)
val PlasmaPink = Color(0xFFF72585)
val NebulaIndigo = Color(0xFF5A189A)

// Supernova Theme Color Palette
val SupernovaVoid = Color(0xFF0D0502)
val SupernovaDarkSurface = Color(0xFF1A0B05)
val SupernovaCard = Color(0xFF281007)
val SupernovaCardBorder = Color(0x44FFB703)

val SupernovaGold = Color(0xFFFFB703)
val SupernovaOrange = Color(0xFFFB8500)
val SupernovaFlare = Color(0xFFFF4D00)
val SupernovaCrimson = Color(0xFFD62828)
val SupernovaAmber = Color(0xFFFFD166)

val CosmicTextPrimary = Color(0xFFF8F9FA)
val CosmicTextSecondary = Color(0xFFB8C0EC)
val CosmicTextMuted = Color(0xFF6C757D)

val GlowPurple = Color(0x889D4EDD)
val GlowCyan = Color(0x8800F5D4)
