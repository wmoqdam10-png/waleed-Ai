package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AccretionCyan
import com.example.ui.theme.CosmicTextMuted
import com.example.ui.theme.CosmicTextPrimary
import com.example.ui.theme.CosmicTextSecondary
import com.example.ui.theme.CosmicVoid
import com.example.ui.theme.NebulaIndigo
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SingularityPurple
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.viewmodel.DjiMainViewModel

@Composable
fun VideoStudioScreen(
    viewModel: DjiMainViewModel,
    modifier: Modifier = Modifier
) {
    var videoPrompt by remember { mutableStateOf("هولوجرام ليزري لقطة ثقب أسود يدور بسرعة فائقة في أطراف المجرة") }
    var selectedResolution by remember { mutableStateOf("1080p") }
    var selectedAspectRatio by remember { mutableStateOf("16:9") }

    var isGeneratingVideo by remember { mutableStateOf(false) }
    var generatedVideoStatus by remember { mutableStateOf<String?>(null) }

    val videoPresets = listOf(
        "حركة كاميرا سينمائية زوم ببطء",
        "طيران طائرة درون فوق ثقب أسود",
        "تأثير أنمي سايبربانك متحرك",
        "تصوير بطيء لأطياف الضوء"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CosmicVoid),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder)
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = null,
                        tint = SingularityPurple,
                        modifier = Modifier.size(32.dp)
                    )

                    Column {
                        Text(
                            text = "استوديو VEO 3.1 للفيديو الذكي",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CosmicTextPrimary
                        )
                        Text(
                            text = "توليد مقاطع فيديو سينمائية متحركة من الأوصاف النصية بأعلى جودة",
                            fontSize = 12.sp,
                            color = CosmicTextSecondary
                        )
                    }
                }
            }
        }

        // Options
        item {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "دقة الفيديو (Video Resolution):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccretionCyan
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("720p", "1080p", "4K Ultra").forEach { res ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedResolution == res) SingularityPurple else SurfaceCard,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedResolution = res }
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = res,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CosmicTextPrimary,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Text(
                    text = "نسبة العرض (Aspect Ratio):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccretionCyan
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("16:9", "9:16", "1:1").forEach { ratio ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedAspectRatio == ratio) AccretionCyan else SurfaceCard,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedAspectRatio = ratio }
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = ratio,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedAspectRatio == ratio) Color.Black else CosmicTextPrimary,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Text(
                    text = "وصف مشهد الفيديو (Video Prompt):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccretionCyan
                )

                OutlinedTextField(
                    value = videoPrompt,
                    onValueChange = { videoPrompt = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("video_prompt_input"),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccretionCyan,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = CosmicTextPrimary,
                        unfocusedTextColor = CosmicTextPrimary,
                        focusedContainerColor = SurfaceCard,
                        unfocusedContainerColor = SurfaceCard
                    ),
                    maxLines = 4
                )

                Text(
                    text = "أنماط حركة الكاميرا الموصى بها:",
                    fontSize = 12.sp,
                    color = CosmicTextMuted
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(videoPresets) { preset ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SurfaceCardBorder,
                            modifier = Modifier.clickable { videoPrompt = "$videoPrompt ، $preset" }
                        ) {
                            Text(
                                text = preset,
                                fontSize = 11.sp,
                                color = CosmicTextSecondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        if (videoPrompt.isNotBlank()) {
                            isGeneratingVideo = true
                            generatedVideoStatus = "جاري إرسال الطلب لنموذج Veo 3.1 Fast Video..."
                        }
                    },
                    enabled = !isGeneratingVideo && videoPrompt.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("generate_video_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SingularityPurple),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (isGeneratingVideo) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("جاري توليد مشاهد الفيديو بـ VEO...", color = Color.White, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("إنشاء مشهد الفيديو بـ Veo 3.1", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }

        // Render Canvas Result
        item {
            if (generatedVideoStatus != null) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "🎬 مشهد الفيديو المولد عبر Veo 3.1",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = CosmicTextPrimary
                            )

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(CosmicVoid)
                                    .border(1.dp, AccretionCyan, RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayCircleFilled,
                                        contentDescription = "Play Video",
                                        tint = AccretionCyan,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Text(
                                        text = "جاهز للعرض • $selectedResolution • $selectedAspectRatio",
                                        fontSize = 12.sp,
                                        color = CosmicTextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
