package com.example.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageStudioScreen
import com.example.ui.screens.VideoStudioScreen
import com.example.ui.screens.VoiceStudioScreen
import com.example.ui.theme.AccretionCyan
import com.example.ui.theme.CosmicTextMuted
import com.example.ui.theme.CosmicTextPrimary
import com.example.ui.theme.CosmicVoid
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SingularityPurple
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.viewmodel.DjiMainViewModel

enum class DjiTab(val title: String, val icon: ImageVector) {
    HOME("الرئيسية", Icons.Default.Home),
    CHAT("المحادثة", Icons.Default.ChatBubbleOutline),
    IMAGE("الصور", Icons.Default.Image),
    VOICE("الصوت", Icons.Default.GraphicEq),
    VIDEO("Veo فيديو", Icons.Default.Videocam),
    HISTORY("السجل", Icons.Default.History)
}

@Composable
fun DjiMainAppScreen(
    viewModel: DjiMainViewModel
) {
    var selectedTab by remember { mutableStateOf(DjiTab.HOME) }

    Scaffold(
        containerColor = CosmicVoid,
        bottomBar = {
            Surface(
                color = SurfaceCard.copy(alpha = 0.95f),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("dji_bottom_navigation_bar")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DjiTab.values().forEach { tab ->
                        val isSelected = selectedTab == tab

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedTab = tab }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("tab_${tab.name.lowercase()}")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) SingularityPurple else Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) AccretionCyan else CosmicTextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) AccretionCyan else CosmicTextMuted
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                DjiTab.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToChat = { selectedTab = DjiTab.CHAT },
                    onNavigateToImage = { selectedTab = DjiTab.IMAGE },
                    onNavigateToVoice = { selectedTab = DjiTab.VOICE },
                    onNavigateToVideo = { selectedTab = DjiTab.VIDEO }
                )
                DjiTab.CHAT -> ChatScreen(viewModel = viewModel)
                DjiTab.IMAGE -> ImageStudioScreen(viewModel = viewModel)
                DjiTab.VOICE -> VoiceStudioScreen(viewModel = viewModel)
                DjiTab.VIDEO -> VideoStudioScreen(viewModel = viewModel)
                DjiTab.HISTORY -> HistoryScreen(
                    viewModel = viewModel,
                    onNavigateToChat = { selectedTab = DjiTab.CHAT }
                )
            }
        }
    }
}
