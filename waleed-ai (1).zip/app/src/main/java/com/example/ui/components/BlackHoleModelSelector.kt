package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.repository.DjiModelCatalog
import com.example.data.repository.DjiModelInfo
import com.example.ui.theme.AccretionCyan
import com.example.ui.theme.CosmicTextMuted
import com.example.ui.theme.CosmicTextPrimary
import com.example.ui.theme.CosmicTextSecondary
import com.example.ui.theme.EventHorizonDark
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SingularityPurple
import com.example.ui.theme.SupernovaGold
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder

/**
 * Interactive Model Selection Pill designed to fit inside the Black Hole Interface.
 */
@Composable
fun BlackHoleModelSelectorPill(
    selectedModel: DjiModelInfo,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val categoryIcon = when (selectedModel.category) {
        "code" -> Icons.Default.Code
        "image" -> Icons.Default.Image
        "audio" -> Icons.Default.GraphicEq
        "video" -> Icons.Default.Videocam
        else -> Icons.Default.AutoAwesome
    }

    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
        shadowElevation = 8.dp,
        modifier = modifier
            .testTag("black_hole_model_selector_pill")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                SingularityPurple
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(12.dp)
                )
            }

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = selectedModel.name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CosmicTextPrimary
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = selectedModel.badge,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = "قائمة اختيار النماذج",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * Quick Toggle Chips for switching directly within the Black Hole Header.
 */
@Composable
fun BlackHoleQuickModelBar(
    selectedModelId: String,
    onModelSelected: (DjiModelInfo) -> Unit,
    onOpenFullMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    val quickModels = remember {
        listOf(
            DjiModelCatalog.getModelById("gemini-3.5-flash"),
            DjiModelCatalog.getModelById("gemini-3.1-pro-preview"),
            DjiModelCatalog.getModelById("gemini-3.1-flash-lite-preview"),
            DjiModelCatalog.getModelById("gemini-3.1-flash-image-preview")
        )
    }

    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(quickModels) { model ->
            val isSelected = model.id == selectedModelId

            val chipIcon = when (model.id) {
                "gemini-3.1-pro-preview" -> Icons.Default.Psychology
                "gemini-3.1-flash-lite-preview" -> Icons.Default.Speed
                "gemini-3.1-flash-image-preview" -> Icons.Default.Science
                else -> Icons.Default.AutoAwesome
            }

            FilterChip(
                selected = isSelected,
                onClick = { onModelSelected(model) },
                label = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = chipIcon,
                            contentDescription = null,
                            tint = if (isSelected) Color.Black else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = when (model.id) {
                                "gemini-3.5-flash" -> "Flash 3.5"
                                "gemini-3.1-pro-preview" -> "Pro 3.1"
                                "gemini-3.1-flash-lite-preview" -> "Lite"
                                "gemini-3.1-flash-image-preview" -> "4K تجريبي"
                                else -> model.name
                            },
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.Black else CosmicTextPrimary
                        )
                    }
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    containerColor = EventHorizonDark.copy(alpha = 0.8f),
                    labelColor = CosmicTextPrimary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = SurfaceCardBorder,
                    selectedBorderColor = MaterialTheme.colorScheme.primary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("black_hole_quick_chip_${model.id}")
            )
        }

        item {
            Surface(
                onClick = onOpenFullMenu,
                shape = RoundedCornerShape(12.dp),
                color = SurfaceCard.copy(alpha = 0.8f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("open_full_model_menu_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "كل النماذج (8)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

/**
 * Full Selection Menu Dialog allowing users to toggle between different Gemini model versions
 * like Pro, Flash, or experimental variants.
 */
@Composable
fun BlackHoleModelSelectionDialog(
    selectedModelId: String,
    onModelSelected: (DjiModelInfo) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedCategoryFilter by remember { mutableStateOf("all") }

    val filteredModels = remember(selectedCategoryFilter) {
        when (selectedCategoryFilter) {
            "flash" -> DjiModelCatalog.models.filter { it.id.contains("flash") && !it.id.contains("image") && !it.id.contains("audio") }
            "pro" -> DjiModelCatalog.models.filter { it.id.contains("pro") }
            "experimental" -> DjiModelCatalog.models.filter {
                it.id.contains("image") || it.id.contains("audio") || it.id.contains("video") || it.id.contains("preview")
            }
            else -> DjiModelCatalog.models
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("black_hole_model_selection_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = EventHorizonDark.copy(alpha = 0.96f)
            ),
            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.primary,
                                            SingularityPurple
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "اختيار نموذج Gemini للثقب الأسود",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = CosmicTextPrimary
                            )
                            Text(
                                text = "تنقل بين اصدارات Flash و Pro والنسخ التجريبية",
                                fontSize = 11.sp,
                                color = CosmicTextMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Category Filter Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val filterOptions = listOf(
                        "all" to "الكل (8)",
                        "flash" to "⚡ Flash",
                        "pro" to "🧠 Pro",
                        "experimental" to "🧪 تجريبي"
                    )

                    filterOptions.forEach { (key, label) ->
                        val isFilterSelected = selectedCategoryFilter == key
                        Surface(
                            onClick = { selectedCategoryFilter = key },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isFilterSelected) MaterialTheme.colorScheme.primary else SurfaceCard,
                            border = BorderStroke(
                                1.dp,
                                if (isFilterSelected) MaterialTheme.colorScheme.primary else SurfaceCardBorder
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isFilterSelected) Color.Black else CosmicTextPrimary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Models List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredModels) { model ->
                        val isSelected = model.id == selectedModelId

                        val modelIcon = when {
                            model.id.contains("pro") -> Icons.Default.Psychology
                            model.id.contains("lite") -> Icons.Default.Speed
                            model.category == "image" -> Icons.Default.Image
                            model.category == "audio" -> Icons.Default.GraphicEq
                            model.category == "video" -> Icons.Default.Videocam
                            else -> Icons.Default.AutoAwesome
                        }

                        Surface(
                            onClick = {
                                onModelSelected(model)
                                onDismiss()
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) SurfaceCard else EventHorizonDark,
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else SurfaceCardBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("model_dialog_item_${model.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) {
                                                Brush.radialGradient(
                                                    listOf(
                                                        MaterialTheme.colorScheme.primary,
                                                        PlasmaPink
                                                    )
                                                )
                                            } else {
                                                Brush.radialGradient(
                                                    listOf(
                                                        SurfaceCard,
                                                        SingularityPurple.copy(alpha = 0.5f)
                                                    )
                                                )
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = modelIcon,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.Black else AccretionCyan,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = model.name,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CosmicTextPrimary
                                        )

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                                                    else SingularityPurple.copy(alpha = 0.3f)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = model.badge,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary else AccretionCyan
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Text(
                                        text = model.descriptionAr,
                                        fontSize = 11.sp,
                                        color = CosmicTextSecondary,
                                        maxLines = 2
                                    )
                                }

                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "النموذج النشط",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "إغلاق وتأكيد الاختيار",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
