package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BlackHoleModelSelectionDialog
import com.example.ui.components.ChatMessageBubble
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.ModelSelectorBar
import com.example.ui.theme.AccretionCyan
import com.example.ui.theme.CosmicTextMuted
import com.example.ui.theme.CosmicTextPrimary
import com.example.ui.theme.CosmicTextSecondary
import com.example.ui.theme.CosmicVoid
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SingularityPurple
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SupernovaGold
import com.example.ui.theme.ThemeMode
import com.example.viewmodel.DjiMainViewModel

@Composable
fun ChatScreen(
    viewModel: DjiMainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val messages by viewModel.currentMessages.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val systemInstruction by viewModel.systemInstruction.collectAsStateWithLifecycle()
    val thinkingLevel by viewModel.thinkingLevel.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val colorIntensity by viewModel.colorIntensity.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var showSettingsPanel by remember { mutableStateOf(false) }
    var showModelSelectionDialog by remember { mutableStateOf(false) }

    if (showModelSelectionDialog) {
        BlackHoleModelSelectionDialog(
            selectedModelId = selectedModel.id,
            onModelSelected = { model -> viewModel.selectModel(model.id) },
            onDismiss = { showModelSelectionDialog = false }
        )
    }

    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CosmicVoid)
    ) {
        // 1. Model Selector Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceCard.copy(alpha = 0.9f))
                .border(1.dp, SurfaceCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = AccretionCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "استوديو المحادثة الذكية",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = CosmicTextPrimary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { showModelSelectionDialog = true },
                        modifier = Modifier.testTag("open_model_dialog_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "قائمة اختيار النماذج",
                            tint = AccretionCyan
                        )
                    }

                    IconButton(
                        onClick = { showSettingsPanel = !showSettingsPanel },
                        modifier = Modifier.testTag("settings_toggle_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "الإعدادات المتقدمة",
                            tint = if (showSettingsPanel) AccretionCyan else CosmicTextMuted
                        )
                    }
                }
            }

            ModelSelectorBar(
                selectedModelId = selectedModel.id,
                onModelSelected = { model -> viewModel.selectModel(model.id) }
            )

            // Settings Panel (Collapsible)
            AnimatedVisibility(visible = showSettingsPanel) {
                GlassmorphicCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "إعدادات النموذج المتقدمة",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccretionCyan
                        )

                        OutlinedTextField(
                            value = systemInstruction,
                            onValueChange = { viewModel.setSystemInstruction(it) },
                            label = { Text("توجيهات النظام (System Instruction)", fontSize = 11.sp, color = CosmicTextMuted) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AccretionCyan,
                                unfocusedBorderColor = SurfaceCardBorder,
                                focusedTextColor = CosmicTextPrimary,
                                unfocusedTextColor = CosmicTextPrimary
                            ),
                            maxLines = 2
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "مستوى التفكير العميق (Thinking Level):", fontSize = 11.sp, color = CosmicTextMuted)

                            listOf("low", "high", "none").forEach { level ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (thinkingLevel == level) SingularityPurple else SurfaceCard,
                                    modifier = Modifier.clickable { viewModel.setThinkingLevel(level) }
                                ) {
                                    Text(
                                        text = level,
                                        fontSize = 10.sp,
                                        color = CosmicTextPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "مظهر التطبيق الكوني:", fontSize = 11.sp, color = CosmicTextMuted)

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (themeMode == ThemeMode.BLACK_HOLE) AccretionCyan else SurfaceCard,
                                modifier = Modifier.clickable { viewModel.setThemeMode(ThemeMode.BLACK_HOLE) }
                            ) {
                                Text(
                                    text = "🌌 الثقب الأسود",
                                    fontSize = 10.sp,
                                    color = if (themeMode == ThemeMode.BLACK_HOLE) Color.Black else CosmicTextPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (themeMode == ThemeMode.SUPERNOVA) SupernovaGold else SurfaceCard,
                                modifier = Modifier.clickable { viewModel.setThemeMode(ThemeMode.SUPERNOVA) }
                            ) {
                                Text(
                                    text = "💥 المستعر الأعظم",
                                    fontSize = 10.sp,
                                    color = if (themeMode == ThemeMode.SUPERNOVA) Color.Black else CosmicTextPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Chat Message Stream
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (messages.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = AccretionCyan,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "مرحباً بك في DJI AI",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = CosmicTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "أنت تتحدث حالياً مع نموذج (${selectedModel.name}). اكتب سؤالك أو فكرتك للبدء فوراً!",
                        fontSize = 12.sp,
                        color = CosmicTextSecondary,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    items(messages) { message ->
                        ChatMessageBubble(message = message)
                    }

                    if (isLoading) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    color = AccretionCyan,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "جاري التفكير والتوليد عبر ${selectedModel.name}...",
                                    fontSize = 12.sp,
                                    color = CosmicTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Bottom Prompt Input Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 70.dp),
            color = SurfaceCard.copy(alpha = 0.95f),
            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("اكتب رسالتك أو استفسارك هنا...", fontSize = 13.sp, color = CosmicTextMuted) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_prompt_input"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccretionCyan,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = CosmicTextPrimary,
                        unfocusedTextColor = CosmicTextPrimary,
                        focusedContainerColor = CosmicVoid,
                        unfocusedContainerColor = CosmicVoid
                    ),
                    maxLines = 4
                )

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            val textToSend = inputText
                            inputText = ""
                            viewModel.sendChatMessage(textToSend)
                        }
                    },
                    enabled = !isLoading && inputText.isNotBlank(),
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(if (inputText.isNotBlank()) AccretionCyan else SurfaceCardBorder)
                        .testTag("send_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "إرسال",
                        tint = if (inputText.isNotBlank()) Color.Black else CosmicTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
