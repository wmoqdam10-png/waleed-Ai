package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AccretionCyan
import com.example.ui.theme.CosmicVoid
import com.example.ui.theme.NebulaIndigo
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SingularityPurple
import com.example.ui.theme.SupernovaAmber
import com.example.ui.theme.SupernovaCrimson
import com.example.ui.theme.SupernovaFlare
import com.example.ui.theme.SupernovaGold
import com.example.ui.theme.SupernovaOrange
import com.example.ui.theme.SupernovaVoid
import com.example.ui.theme.ThemeMode
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BlackHoleHeroHeader(
    modifier: Modifier = Modifier,
    height: Dp = 180.dp,
    isLoading: Boolean = false,
    themeMode: ThemeMode = ThemeMode.BLACK_HOLE,
    colorIntensity: Float = 1.0f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "BlackHoleRotation")

    val isSupernova = (themeMode == ThemeMode.SUPERNOVA)

    // Dynamic Color Mapping based on Theme Mode
    val primaryGlow = if (isSupernova) SupernovaGold else AccretionCyan
    val secondaryGlow = if (isSupernova) SupernovaOrange else SingularityPurple
    val accentGlow = if (isSupernova) SupernovaFlare else PlasmaPink
    val deepGlow = if (isSupernova) SupernovaCrimson else NebulaIndigo
    val voidColor = if (isSupernova) SupernovaVoid else CosmicVoid

    fun alpha(baseAlpha: Float): Float = (baseAlpha * colorIntensity).coerceIn(0.01f, 1.0f)

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Bespoke Processing Animation specs for when isLoading == true
    val fastCoreRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fastCoreRotation"
    )

    val counterCoreRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counterCoreRotation"
    )

    val corePulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "corePulseAlpha"
    )

    val waveRadiusRatio by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waveRadiusRatio"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = (size.height / 2.8f) * pulseScale

        // 1. Draw Star Dust Background
        for (i in 0..30) {
            val starX = (i * 37) % size.width
            val starY = (i * 53) % size.height
            val starAlpha = alpha(((i % 5) + 1) * 0.15f)
            val starColor = if (isSupernova) SupernovaAmber else Color.White
            drawCircle(
                color = starColor.copy(alpha = starAlpha),
                radius = (i % 3 + 1).toFloat(),
                center = Offset(starX, starY)
            )
        }

        // 2. Draw Gravitational Lensing / Stellar Outer Halo
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    primaryGlow.copy(alpha = alpha(if (isLoading) 0.70f else 0.45f)),
                    secondaryGlow.copy(alpha = alpha(if (isLoading) 0.50f else 0.30f)),
                    deepGlow.copy(alpha = alpha(0.12f)),
                    voidColor
                ),
                center = center,
                radius = radius * 2.8f
            ),
            center = center,
            radius = radius * 2.8f
        )

        // 3. Draw Swirling Accretion Disk / Stellar Flare Rings
        rotate(if (isLoading) rotationAngle * 2f else rotationAngle, pivot = center) {
            // Outer Ring
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        primaryGlow,
                        secondaryGlow,
                        accentGlow,
                        primaryGlow
                    ),
                    center = center
                ),
                center = center,
                radius = radius * 1.8f,
                style = Stroke(width = (6 * colorIntensity.coerceIn(0.6f, 1.5f)).dp.toPx())
            )

            // Inner Ring
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        accentGlow,
                        secondaryGlow,
                        primaryGlow,
                        accentGlow
                    ),
                    center = center
                ),
                center = center,
                radius = radius * 1.35f,
                style = Stroke(width = (4 * colorIntensity.coerceIn(0.6f, 1.5f)).dp.toPx())
            )

            // Accretion / Solar Prominence Particles
            for (i in 0 until 12) {
                val angleRad = Math.toRadians((i * 30).toDouble())
                val pX = center.x + (radius * 1.5f * cos(angleRad)).toFloat()
                val pY = center.y + (radius * 1.5f * sin(angleRad)).toFloat()
                drawCircle(
                    color = if (i % 2 == 0) primaryGlow else accentGlow,
                    radius = 3.dp.toPx() * colorIntensity.coerceIn(0.7f, 1.3f),
                    center = Offset(pX, pY)
                )
            }
        }

        // 4. Draw Photon Sphere / Solar Surface Corona Ring
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White,
                    primaryGlow.copy(alpha = alpha(0.9f)),
                    secondaryGlow.copy(alpha = alpha(0.6f)),
                    Color.Transparent
                ),
                center = center,
                radius = radius * 1.05f
            ),
            center = center,
            radius = radius * 1.05f
        )

        // 5. Draw Core Void / Stellar Core
        drawCircle(
            color = if (isSupernova) Color(0xFF150400) else Color.Black,
            radius = radius * 0.85f,
            center = center
        )

        // 6. Center Singularity Core & Bespoke Processing Loading Animation
        if (isLoading) {
            val innerVoidRadius = radius * 0.85f

            // 6a. Expanding Concentric Shockwave Pulse
            val currentWaveRadius = innerVoidRadius * waveRadiusRatio
            val waveAlpha = alpha(((1f - waveRadiusRatio) * corePulseAlpha).coerceIn(0f, 1f))
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlow.copy(alpha = waveAlpha * 0.9f),
                        accentGlow.copy(alpha = waveAlpha * 0.5f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = currentWaveRadius.coerceAtLeast(1f)
                ),
                center = center,
                radius = currentWaveRadius,
                style = Stroke(width = 3.dp.toPx())
            )

            // 6b. Inward Gravitational / Solar Flare Rays
            for (i in 0 until 8) {
                val angleRad = Math.toRadians((i * 45 + fastCoreRotation * 0.5f).toDouble())
                val outerPointX = center.x + (innerVoidRadius * 0.8f * cos(angleRad)).toFloat()
                val outerPointY = center.y + (innerVoidRadius * 0.8f * sin(angleRad)).toFloat()
                val innerPointX = center.x + (innerVoidRadius * 0.25f * cos(angleRad)).toFloat()
                val innerPointY = center.y + (innerVoidRadius * 0.25f * sin(angleRad)).toFloat()

                drawLine(
                    color = primaryGlow.copy(alpha = alpha(0.4f * corePulseAlpha)),
                    start = Offset(outerPointX, outerPointY),
                    end = Offset(innerPointX, innerPointY),
                    strokeWidth = 1.5.dp.toPx()
                )
            }

            // 6c. High-Speed Outer Arc Spinner
            rotate(fastCoreRotation, pivot = center) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            primaryGlow,
                            accentGlow,
                            secondaryGlow,
                            Color.Transparent
                        ),
                        center = center
                    ),
                    startAngle = 0f,
                    sweepAngle = 240f,
                    useCenter = false,
                    topLeft = Offset(center.x - innerVoidRadius * 0.65f, center.y - innerVoidRadius * 0.65f),
                    size = Size(innerVoidRadius * 1.3f, innerVoidRadius * 1.3f),
                    style = Stroke(width = 3.5.dp.toPx())
                )

                // 4 Orbiting Photon / Solar Energy Nodes
                for (i in 0 until 4) {
                    val angleRad = Math.toRadians((i * 90).toDouble())
                    val pX = center.x + (innerVoidRadius * 0.65f * cos(angleRad)).toFloat()
                    val pY = center.y + (innerVoidRadius * 0.65f * sin(angleRad)).toFloat()
                    drawCircle(
                        color = Color.White,
                        radius = 3.5.dp.toPx(),
                        center = Offset(pX, pY)
                    )
                }
            }

            // 6d. Counter-Spinning Inner Arc Spinner
            rotate(counterCoreRotation, pivot = center) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            accentGlow,
                            primaryGlow,
                            Color.Transparent
                        ),
                        center = center
                    ),
                    startAngle = 90f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = Offset(center.x - innerVoidRadius * 0.40f, center.y - innerVoidRadius * 0.40f),
                    size = Size(innerVoidRadius * 0.8f, innerVoidRadius * 0.8f),
                    style = Stroke(width = 2.5.dp.toPx())
                )
            }

            // 6e. Glowing Pulsing Singularity Quantum / Solar Core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        primaryGlow.copy(alpha = alpha(0.9f * corePulseAlpha)),
                        accentGlow.copy(alpha = alpha(0.6f * corePulseAlpha)),
                        Color.Transparent
                    ),
                    center = center,
                    radius = innerVoidRadius * 0.28f
                ),
                center = center,
                radius = innerVoidRadius * 0.28f
            )

            // 6f. Center Intense Light Point
            drawCircle(
                color = Color.White,
                radius = 4.dp.toPx() * corePulseAlpha,
                center = center
            )
        } else {
            // Standard Center Light Point
            drawCircle(
                color = primaryGlow,
                radius = (3 * colorIntensity.coerceIn(0.8f, 1.4f)).dp.toPx(),
                center = center
            )
        }
    }
}

