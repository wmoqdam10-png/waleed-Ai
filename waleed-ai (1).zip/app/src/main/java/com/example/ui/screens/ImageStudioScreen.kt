package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AccretionCyan
import com.example.ui.theme.CosmicTextMuted
import com.example.ui.theme.CosmicTextPrimary
import com.example.ui.theme.CosmicTextSecondary
import com.example.ui.theme.CosmicVoid
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SingularityPurple
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.viewmodel.DjiMainViewModel

@Composable
fun ImageStudioScreen(
    viewModel: DjiMainViewModel,
    modifier: Modifier = Modifier
) {
    var promptText by remember { mutableStateOf("") }
    var selectedAspectRatio by remember { mutableStateOf("1:1") }
    var selectedImageModel by remember { mutableStateOf("gemini-2.5-flash-image") }

    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val statusMessage by viewModel.imageStatusMessage.collectAsStateWithLifecycle()
    val generatedImageUrl by viewModel.generatedImageUrl.collectAsStateWithLifecycle()

    val promptSuggestions = listOf(
        "ثقب أسود خيالي بضوء النيون والبنفسجي مع قرص تجمعي متلألئ",
        "مدينة سايبربانك مستقبيلة ذات أبراج عالية وأضواء ليزرية 4K",
        "روبوت ذكاء اصطناعي فضائي بواجهة زجاجية متطورة وسينمائية",
        "لوحة زيتية تجريدية لكوكب زحل مع خلفية النجوم المتلألئة"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CosmicVoid),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder)
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = AccretionCyan,
                        modifier = Modifier.size(32.dp)
                    )

                    Column {
                        Text(
                            text = "استوديو الصور الذكية (Gemini Image Studio)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CosmicTextPrimary
                        )
                        Text(
                            text = "توليد وتصاميم بصرية فائقة الدقة بنماذج Nano Banana و 4K",
                            fontSize = 12.sp,
                            color = CosmicTextSecondary
                        )
                    }
                }
            }
        }

        // Configuration Card
        item {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Model Switcher for Image Studio
                Text(
                    text = "اختر نموذج توليد الصور:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccretionCyan
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedImageModel == "gemini-2.5-flash-image") SingularityPurple else SurfaceCard,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedImageModel = "gemini-2.5-flash-image" }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(
                            text = "Nano Banana (Standard)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CosmicTextPrimary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedImageModel == "gemini-3.1-flash-image-preview") AccretionCyan else SurfaceCard,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedImageModel = "gemini-3.1-flash-image-preview" }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(
                            text = "Flash Image (HD 4K)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedImageModel == "gemini-3.1-flash-image-preview") Color.Black else CosmicTextPrimary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                // Aspect Ratio Selection
                Text(
                    text = "نسبة أبعاد الصورة (Aspect Ratio):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccretionCyan
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("1:1", "16:9", "9:16", "4:3").forEach { ratio ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedAspectRatio == ratio) PlasmaPink else SurfaceCard,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedAspectRatio = ratio }
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = ratio,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CosmicTextPrimary,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                // Prompt Input
                Text(
                    text = "وصف الصورة المطلوبة (Prompt):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccretionCyan
                )

                OutlinedTextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    placeholder = { Text("مثال: ثقب أسود بعمق مجرة فضائية مع ضوء نيون أزرق وبنفسجي سينمائي...", fontSize = 12.sp, color = CosmicTextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("image_prompt_input"),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccretionCyan,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = CosmicTextPrimary,
                        unfocusedTextColor = CosmicTextPrimary,
                        focusedContainerColor = SurfaceCard,
                        unfocusedContainerColor = SurfaceCard
                    ),
                    maxLines = 4
                )

                // Prompt Suggestions
                Text(
                    text = "اقتراحات الأوصاف الجاهزة:",
                    fontSize = 12.sp,
                    color = CosmicTextMuted
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(promptSuggestions) { suggestion ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SurfaceCardBorder,
                            modifier = Modifier.clickable { promptText = suggestion }
                        ) {
                            Text(
                                text = suggestion,
                                fontSize = 11.sp,
                                color = CosmicTextSecondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        if (promptText.isNotBlank()) {
                            viewModel.generateImage(promptText, selectedAspectRatio, selectedImageModel)
                        }
                    },
                    enabled = !isLoading && promptText.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("generate_image_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AccretionCyan),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            color = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("جاري معالجة الصورة والتصميم...", color = Color.Black, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("توليد الصورة الآن", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }

        // Result Canvas
        item {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                if (statusMessage != null) {
                    GlassmorphicCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Text(
                            text = statusMessage ?: "",
                            fontSize = 13.sp,
                            color = AccretionCyan,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                if (generatedImageUrl != null) {
                    GlassmorphicCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "🎨 النتيجة البصرية المعالجة",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = CosmicTextPrimary
                            )

                            AsyncImage(
                                model = generatedImageUrl,
                                contentDescription = "Generated AI Image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(280.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(2.dp, AccretionCyan, RoundedCornerShape(16.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}
