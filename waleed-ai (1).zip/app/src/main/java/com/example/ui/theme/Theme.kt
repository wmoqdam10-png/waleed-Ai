package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class ThemeMode {
    BLACK_HOLE,
    SUPERNOVA
}

private val DjiDarkColorScheme = darkColorScheme(
    primary = AccretionCyan,
    onPrimary = Color.Black,
    primaryContainer = NebulaIndigo,
    onPrimaryContainer = CosmicTextPrimary,
    secondary = SingularityPurple,
    onSecondary = Color.White,
    secondaryContainer = SurfaceCard,
    onSecondaryContainer = CosmicTextPrimary,
    tertiary = PlasmaPink,
    onTertiary = Color.White,
    background = CosmicVoid,
    onBackground = CosmicTextPrimary,
    surface = EventHorizonDark,
    onSurface = CosmicTextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = CosmicTextSecondary,
    outline = SurfaceCardBorder
)

private val SupernovaColorScheme = darkColorScheme(
    primary = SupernovaGold,
    onPrimary = Color.Black,
    primaryContainer = SupernovaFlare,
    onPrimaryContainer = Color.White,
    secondary = SupernovaOrange,
    onSecondary = Color.Black,
    secondaryContainer = SupernovaCard,
    onSecondaryContainer = CosmicTextPrimary,
    tertiary = SupernovaAmber,
    onTertiary = Color.Black,
    background = SupernovaVoid,
    onBackground = CosmicTextPrimary,
    surface = SupernovaDarkSurface,
    onSurface = CosmicTextPrimary,
    surfaceVariant = SupernovaCard,
    onSurfaceVariant = CosmicTextSecondary,
    outline = SupernovaCardBorder
)

@Composable
fun DjiTheme(
    themeMode: ThemeMode = ThemeMode.BLACK_HOLE,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        ThemeMode.BLACK_HOLE -> DjiDarkColorScheme
        ThemeMode.SUPERNOVA -> SupernovaColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Kept for backward compatibility if referenced
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    DjiTheme(content = content)
}
