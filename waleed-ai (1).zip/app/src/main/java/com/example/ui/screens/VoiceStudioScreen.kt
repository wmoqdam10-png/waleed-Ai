package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AccretionCyan
import com.example.ui.theme.CosmicTextMuted
import com.example.ui.theme.CosmicTextPrimary
import com.example.ui.theme.CosmicTextSecondary
import com.example.ui.theme.CosmicVoid
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SingularityPurple
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.viewmodel.DjiMainViewModel

@Composable
fun VoiceStudioScreen(
    viewModel: DjiMainViewModel,
    modifier: Modifier = Modifier
) {
    var textToSpeechInput by remember { mutableStateOf("مرحباً بك في تطبيق DJI الذكي! أطلب منك الاسترخاء بينما أقوم بمعالجة أفكارك.") }
    var selectedVoice by remember { mutableStateOf("Kore") }

    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val speechStatus by viewModel.speechStatusMessage.collectAsStateWithLifecycle()

    val voicesList = listOf(
        Pair("Kore", "صوت بشرى دافئ وإرشادي"),
        Pair("Fenrir", "صوت عميق واحترافي"),
        Pair("Puck", "صوت حيوي ومرح"),
        Pair("Charon", "صوت هادئ ورسمي"),
        Pair("Aoede", "صوت إعلامي متزن")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CosmicVoid),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder)
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = PlasmaPink,
                        modifier = Modifier.size(32.dp)
                    )

                    Column {
                        Text(
                            text = "استوديو الصوت والنطق (Gemini TTS)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CosmicTextPrimary
                        )
                        Text(
                            text = "تحويل النصوص إلى كلام أصيل بدقة صوتية عالية مع أصوات متعددة",
                            fontSize = 12.sp,
                            color = CosmicTextSecondary
                        )
                    }
                }
            }
        }

        // Voice selection
        item {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "اختر نبرة وقارئ الصوت (Voice Persona):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccretionCyan
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(voicesList) { (name, desc) ->
                        val isSelected = selectedVoice == name
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) PlasmaPink else SurfaceCard,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceCardBorder),
                            modifier = Modifier
                                .width(150.dp)
                                .clickable { selectedVoice = name }
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RecordVoiceOver,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else AccretionCyan,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CosmicTextPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = desc,
                                    fontSize = 10.sp,
                                    color = if (isSelected) Color.White.copy(alpha = 0.8f) else CosmicTextMuted
                                )
                            }
                        }
                    }
                }

                Text(
                    text = "النص المراد تحويله إلى صوت (Text):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccretionCyan
                )

                OutlinedTextField(
                    value = textToSpeechInput,
                    onValueChange = { textToSpeechInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("speech_text_input"),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccretionCyan,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = CosmicTextPrimary,
                        unfocusedTextColor = CosmicTextPrimary,
                        focusedContainerColor = SurfaceCard,
                        unfocusedContainerColor = SurfaceCard
                    ),
                    maxLines = 5
                )

                Button(
                    onClick = {
                        if (textToSpeechInput.isNotBlank()) {
                            viewModel.generateSpeech(textToSpeechInput, selectedVoice)
                        }
                    },
                    enabled = !isLoading && textToSpeechInput.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("generate_speech_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = PlasmaPink),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("جاري معالجة النطق وتوليد الصوت...", color = Color.White, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(imageVector = Icons.Default.Mic, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("توليد الصوت الآن", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }

        // Speech Player Wave Result Card
        item {
            if (speechStatus != null) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "🎙️ المقطع الصوتي المعالج:",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccretionCyan
                            )

                            Text(
                                text = speechStatus ?: "",
                                fontSize = 12.sp,
                                color = CosmicTextSecondary
                            )

                            // Audio Wave Animation Visualizer
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .background(CosmicVoid)
                                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                IconButton(
                                    onClick = { },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(PlasmaPink)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "تشغيل",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    listOf(18, 30, 12, 40, 24, 36, 15, 28, 38, 20, 14, 25).forEach { h ->
                                        Box(
                                            modifier = Modifier
                                                .width(4.dp)
                                                .height(h.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(AccretionCyan)
                                        )
                                    }
                                }

                                Text(text = "00:15", fontSize = 11.sp, color = CosmicTextMuted)
                            }
                        }
                    }
                }
            }
        }
    }
}
