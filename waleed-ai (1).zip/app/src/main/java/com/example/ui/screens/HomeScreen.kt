package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.DjiModelCatalog
import com.example.data.repository.DjiModelInfo
import com.example.ui.components.BlackHoleHeroHeader
import com.example.ui.components.BlackHoleModelSelectionDialog
import com.example.ui.components.BlackHoleModelSelectorPill
import com.example.ui.components.BlackHoleQuickModelBar
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AccretionCyan
import com.example.ui.theme.CosmicTextMuted
import com.example.ui.theme.CosmicTextPrimary
import com.example.ui.theme.CosmicTextSecondary
import com.example.ui.theme.CosmicVoid
import com.example.ui.theme.EventHorizonDark
import com.example.ui.theme.GlowCyan
import com.example.ui.theme.GlowPurple
import com.example.ui.theme.NebulaIndigo
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SingularityPurple
import com.example.ui.theme.SupernovaFlare
import com.example.ui.theme.SupernovaGold
import com.example.ui.theme.SupernovaOrange
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.ThemeMode
import com.example.viewmodel.DjiMainViewModel

@Composable
fun HomeScreen(
    viewModel: DjiMainViewModel,
    onNavigateToChat: () -> Unit,
    onNavigateToImage: () -> Unit,
    onNavigateToVoice: () -> Unit,
    onNavigateToVideo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val chatSessions by viewModel.chatSessions.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val colorIntensity by viewModel.colorIntensity.collectAsStateWithLifecycle()

    var showThemeSettingsDialog by remember { mutableStateOf(false) }
    var showModelSelectionDialog by remember { mutableStateOf(false) }

    if (showThemeSettingsDialog) {
        CosmicThemeSettingsDialog(
            currentThemeMode = themeMode,
            currentIntensity = colorIntensity,
            onThemeModeChange = { viewModel.setThemeMode(it) },
            onIntensityChange = { viewModel.setColorIntensity(it) },
            onDismiss = { showThemeSettingsDialog = false }
        )
    }

    if (showModelSelectionDialog) {
        BlackHoleModelSelectionDialog(
            selectedModelId = selectedModel.id,
            onModelSelected = { model -> viewModel.selectModel(model.id) },
            onDismiss = { showModelSelectionDialog = false }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // 1. Black Hole Hero Header with Model Selector Pill
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                contentAlignment = Alignment.Center
            ) {
                BlackHoleHeroHeader(
                    height = 240.dp,
                    isLoading = isLoading,
                    themeMode = themeMode,
                    colorIntensity = colorIntensity
                )

                // Top Right Settings Button
                IconButton(
                    onClick = { showThemeSettingsDialog = true },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.75f))
                        .border(1.dp, MaterialTheme.colorScheme.primary, CircleShape)
                        .testTag("theme_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = "إعدادات المظهر والسمات",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(16.dp)
                ) {
                    // Black Hole Interactive Model Selector Pill
                    BlackHoleModelSelectorPill(
                        selectedModel = selectedModel,
                        onClick = { showModelSelectionDialog = true }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "DJI الذكاء الاصطناعي الشامل",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = CosmicTextPrimary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "منصة متكاملة تضم جميع نماذج Gemini الفائقة للنصوص، الصور، الصوت، والفيديو",
                        fontSize = 12.sp,
                        color = CosmicTextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(0.9f)
                    )
                }
            }
        }

        // 2. Black Hole Quick Model Selection Bar
        item {
            Column(
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Text(
                    text = "تبديل نموذج Gemini في الثقب الأسود:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CosmicTextMuted,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                BlackHoleQuickModelBar(
                    selectedModelId = selectedModel.id,
                    onModelSelected = { model -> viewModel.selectModel(model.id) },
                    onOpenFullMenu = { showModelSelectionDialog = true }
                )
            }
        }

        // 2. Active Model Banner
        item {
            PaddingValues(horizontal = 16.dp, vertical = 8.dp).let { padding ->
                GlassmorphicCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(padding)
                        .testTag("active_model_banner"),
                    borderColor = AccretionCyan
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(AccretionCyan, SingularityPurple)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = "النموذج النشط حالياً",
                                    fontSize = 11.sp,
                                    color = CosmicTextMuted
                                )
                                Text(
                                    text = selectedModel.name,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CosmicTextPrimary
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                onClick = { showModelSelectionDialog = true },
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                modifier = Modifier.testTag("change_model_banner_button")
                            ) {
                                Text(
                                    text = "تغيير",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }

                            Button(
                                onClick = onNavigateToChat,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "بدء المحادثة",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Quick AI Studios Grid Section
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "استوديوهات الذكاء الاصطناعي",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = CosmicTextPrimary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StudioTile(
                        title = "المحادثة العميقة",
                        subtitle = "Flash 3.5 & Pro",
                        icon = Icons.Default.ChatBubbleOutline,
                        gradientColors = listOf(SingularityPurple, NebulaIndigo),
                        onClick = onNavigateToChat,
                        modifier = Modifier.weight(1f)
                    )

                    StudioTile(
                        title = "استوديو الصور",
                        subtitle = "Nano Banana 4K",
                        icon = Icons.Default.Image,
                        gradientColors = listOf(AccretionCyan, SingularityPurple),
                        onClick = onNavigateToImage,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StudioTile(
                        title = "المساعد الصوتي",
                        subtitle = "Gemini TTS",
                        icon = Icons.Default.GraphicEq,
                        gradientColors = listOf(PlasmaPink, SingularityPurple),
                        onClick = onNavigateToVoice,
                        modifier = Modifier.weight(1f)
                    )

                    StudioTile(
                        title = "استوديو Veo",
                        subtitle = "Video Creation",
                        icon = Icons.Default.Videocam,
                        gradientColors = listOf(NebulaIndigo, PlasmaPink),
                        onClick = onNavigateToVideo,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 4. Gemini Models Catalog Carousel
        item {
            Column(
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "دليل النماذج المتوفرة في DJI",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = CosmicTextPrimary
                    )

                    Text(
                        text = "${DjiModelCatalog.models.size} نماذج",
                        fontSize = 12.sp,
                        color = AccretionCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(DjiModelCatalog.models) { model ->
                        ModelCardTile(
                            model = model,
                            isSelected = model.id == selectedModel.id,
                            onSelect = {
                                viewModel.selectModel(model.id)
                                onNavigateToChat()
                            }
                        )
                    }
                }
            }
        }

        // 5. Recent Conversations
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "المحادثات الأخيرة",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = CosmicTextPrimary,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                if (chatSessions.isEmpty()) {
                    GlassmorphicCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "لا توجد محادثات سابقة حتى الآن. انقر فوق 'بدء المحادثة' لبدء أول جلسة مع DJI AI!",
                            fontSize = 13.sp,
                            color = CosmicTextMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                } else {
                    chatSessions.take(3).forEach { session ->
                        GlassmorphicCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            onClick = {
                                viewModel.loadSession(session.id)
                                onNavigateToChat()
                            }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(SurfaceCardBorder),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ChatBubbleOutline,
                                            contentDescription = null,
                                            tint = AccretionCyan,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = session.title,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = CosmicTextPrimary
                                        )
                                        Text(
                                            text = "النموذج: ${session.selectedModel}",
                                            fontSize = 11.sp,
                                            color = CosmicTextMuted
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = SingularityPurple,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudioTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    gradientColors: List<Color>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(110.dp)
            .clickable { onClick() }
            .testTag("studio_tile_$title"),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, SurfaceCardBorder),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            gradientColors.first().copy(alpha = 0.35f),
                            SurfaceCard
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(gradientColors.first().copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CosmicTextPrimary
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = CosmicTextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun ModelCardTile(
    model: DjiModelInfo,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isSelected) SurfaceCardBorder else SurfaceCard,
        border = BorderStroke(1.dp, if (isSelected) AccretionCyan else SurfaceCardBorder),
        modifier = Modifier
            .width(220.dp)
            .height(135.dp)
            .clickable { onSelect() }
            .testTag("model_card_${model.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = model.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = CosmicTextPrimary
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AccretionCyan.copy(alpha = 0.2f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = model.badge,
                        fontSize = 10.sp,
                        color = AccretionCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = model.descriptionAr,
                fontSize = 11.sp,
                color = CosmicTextSecondary,
                lineHeight = 15.sp
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = SingularityPurple,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = "انقر للتفعيل والبدء",
                    fontSize = 10.sp,
                    color = AccretionCyan
                )
            }
        }
    }
}

@Composable
fun CosmicThemeSettingsDialog(
    currentThemeMode: ThemeMode,
    currentIntensity: Float,
    onThemeModeChange: (ThemeMode) -> Unit,
    onIntensityChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        GlassmorphicCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "إعدادات المظهر والسمات الفلكية",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = CosmicTextPrimary
                        )
                    }
                }

                Text(
                    text = "اختر النمط البصري للتطبيق واضبط كثافة الألوان والإشعاع:",
                    fontSize = 12.sp,
                    color = CosmicTextSecondary
                )

                // Theme Mode Selector Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Option 1: Black Hole
                    val isBlackHoleSelected = currentThemeMode == ThemeMode.BLACK_HOLE
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onThemeModeChange(ThemeMode.BLACK_HOLE) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isBlackHoleSelected) SurfaceCard else EventHorizonDark,
                        border = BorderStroke(
                            width = if (isBlackHoleSelected) 2.dp else 1.dp,
                            color = if (isBlackHoleSelected) AccretionCyan else SurfaceCardBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "🌌", fontSize = 24.sp)
                            Text(
                                text = "الثقب الأسود",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isBlackHoleSelected) AccretionCyan else CosmicTextPrimary
                            )
                            Text(
                                text = "أزرق وسماوي كوزميك",
                                fontSize = 10.sp,
                                color = CosmicTextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Option 2: Supernova
                    val isSupernovaSelected = currentThemeMode == ThemeMode.SUPERNOVA
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onThemeModeChange(ThemeMode.SUPERNOVA) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSupernovaSelected) SurfaceCard else EventHorizonDark,
                        border = BorderStroke(
                            width = if (isSupernovaSelected) 2.dp else 1.dp,
                            color = if (isSupernovaSelected) SupernovaGold else SurfaceCardBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "💥", fontSize = 24.sp)
                            Text(
                                text = "المستعر الأعظم",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSupernovaSelected) SupernovaGold else CosmicTextPrimary
                            )
                            Text(
                                text = "ذهبي وناري متوهج",
                                fontSize = 10.sp,
                                color = CosmicTextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Intensity Slider
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "كثافة وقوة إشعاع الألوان:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CosmicTextPrimary
                        )
                        Text(
                            text = "${(currentIntensity * 100).toInt()}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Slider(
                        value = currentIntensity,
                        onValueChange = onIntensityChange,
                        valueRange = 0.3f..1.8f,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = SurfaceCardBorder
                        )
                    )
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "حفظ وإغلاق",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
