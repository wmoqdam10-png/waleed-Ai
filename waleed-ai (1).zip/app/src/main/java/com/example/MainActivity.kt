package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.navigation.DjiMainAppScreen
import com.example.ui.theme.DjiTheme
import com.example.viewmodel.DjiMainViewModel

class MainActivity : ComponentActivity() {

    private val mainViewModel: DjiMainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by mainViewModel.themeMode.collectAsStateWithLifecycle()
            DjiTheme(themeMode = themeMode) {
                DjiMainAppScreen(viewModel = mainViewModel)
            }
        }
    }
}
