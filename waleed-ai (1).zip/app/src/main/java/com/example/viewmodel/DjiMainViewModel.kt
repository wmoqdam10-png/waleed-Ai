package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.local.DjiDatabase
import com.example.data.repository.DjiAiRepository
import com.example.data.repository.DjiModelCatalog
import com.example.data.repository.DjiModelInfo
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DjiMainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DjiAiRepository

    private val _selectedModel = MutableStateFlow<DjiModelInfo>(DjiModelCatalog.models.first())
    val selectedModel: StateFlow<DjiModelInfo> = _selectedModel.asStateFlow()

    private val _currentSessionId = MutableStateFlow<Long?>(null)
    val currentSessionId: StateFlow<Long?> = _currentSessionId.asStateFlow()

    private val _chatSessions = MutableStateFlow<List<ChatSessionEntity>>(emptyList())
    val chatSessions: StateFlow<List<ChatSessionEntity>> = _chatSessions.asStateFlow()

    private val _currentMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val currentMessages: StateFlow<List<ChatMessageEntity>> = _currentMessages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _systemInstruction = MutableStateFlow("أنت DJI AI، المساعد الذكي الفائق المطور بأحدث نماذج Gemini.")
    val systemInstruction: StateFlow<String> = _systemInstruction.asStateFlow()

    private val _thinkingLevel = MutableStateFlow("low")
    val thinkingLevel: StateFlow<String> = _thinkingLevel.asStateFlow()

    private val _temperature = MutableStateFlow(0.7f)
    val temperature: StateFlow<Float> = _temperature.asStateFlow()

    // Theme Mode & Color Intensity State
    private val _themeMode = MutableStateFlow(ThemeMode.BLACK_HOLE)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _colorIntensity = MutableStateFlow(1.0f)
    val colorIntensity: StateFlow<Float> = _colorIntensity.asStateFlow()

    // Generated Image State
    private val _generatedImageUrl = MutableStateFlow<String?>(null)
    val generatedImageUrl: StateFlow<String?> = _generatedImageUrl.asStateFlow()

    private val _imageStatusMessage = MutableStateFlow<String?>(null)
    val imageStatusMessage: StateFlow<String?> = _imageStatusMessage.asStateFlow()

    // Generated Speech State
    private val _speechStatusMessage = MutableStateFlow<String?>(null)
    val speechStatusMessage: StateFlow<String?> = _speechStatusMessage.asStateFlow()

    init {
        val database = DjiDatabase.getDatabase(application)
        repository = DjiAiRepository(database.chatDao())

        // Collect chat sessions
        viewModelScope.launch {
            repository.allSessions.collectLatest { sessions ->
                _chatSessions.value = sessions
                if (_currentSessionId.value == null && sessions.isNotEmpty()) {
                    loadSession(sessions.first().id)
                } else if (sessions.isEmpty()) {
                    createNewSession("محادثة جديدة", _selectedModel.value.id, "chat")
                }
            }
        }
    }

    fun selectModel(modelId: String) {
        val model = DjiModelCatalog.getModelById(modelId)
        _selectedModel.value = model
    }

    fun setSystemInstruction(text: String) {
        _systemInstruction.value = text
    }

    fun setThinkingLevel(level: String) {
        _thinkingLevel.value = level
    }

    fun setTemperature(temp: Float) {
        _temperature.value = temp
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun setColorIntensity(intensity: Float) {
        _colorIntensity.value = intensity.coerceIn(0.3f, 1.8f)
    }

    fun createNewSession(title: String, modelId: String, category: String = "chat") {
        viewModelScope.launch {
            val newId = repository.createNewSession(title, modelId, category)
            _currentSessionId.value = newId
            loadSession(newId)
        }
    }

    fun loadSession(sessionId: Long) {
        _currentSessionId.value = sessionId
        viewModelScope.launch {
            repository.getSessionMessages(sessionId).collectLatest { messages ->
                _currentMessages.value = messages
            }
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                val remaining = _chatSessions.value.filter { it.id != sessionId }
                if (remaining.isNotEmpty()) {
                    loadSession(remaining.first().id)
                } else {
                    createNewSession("محادثة جديدة", _selectedModel.value.id, "chat")
                }
            }
        }
    }

    fun sendChatMessage(userText: String, imageBase64: String? = null) {
        if (userText.isBlank()) return
        val sessionId = _currentSessionId.value ?: return
        val currentModel = _selectedModel.value

        viewModelScope.launch {
            _isLoading.value = true

            // Save user message
            repository.saveMessage(
                sessionId = sessionId,
                sender = "user",
                content = userText,
                modelName = currentModel.name
            )

            // Call Gemini API
            val aiResponse = repository.generateAiResponse(
                prompt = userText,
                modelId = currentModel.id,
                history = _currentMessages.value,
                systemInstructionText = _systemInstruction.value,
                temperature = _temperature.value,
                thinkingLevel = _thinkingLevel.value,
                imageBase64 = imageBase64
            )

            // Save AI response
            repository.saveMessage(
                sessionId = sessionId,
                sender = "dji_ai",
                content = aiResponse,
                modelName = currentModel.name
            )

            _isLoading.value = false
        }
    }

    fun generateImage(prompt: String, aspectRatio: String = "1:1", modelId: String = "gemini-2.5-flash-image") {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true
            _imageStatusMessage.value = "جاري الاتصال بنموذج توليد الصور ($modelId)..."

            val result = repository.generateImagePrompt(prompt, aspectRatio, modelId)
            result.onSuccess { message ->
                _imageStatusMessage.value = message
                _generatedImageUrl.value = "https://picsum.photos/800/800" // Visual representation result
                val sessionId = _currentSessionId.value
                if (sessionId != null) {
                    repository.saveMessage(
                        sessionId = sessionId,
                        sender = "dji_ai",
                        content = "🖼️ **تم توليد الصورة المطلوبة:** $prompt\n\n$message",
                        modelName = modelId,
                        imageUrl = "https://picsum.photos/800/800"
                    )
                }
            }.onFailure { err ->
                _imageStatusMessage.value = "خطأ في توليد الصورة: ${err.localizedMessage}"
            }
            _isLoading.value = false
        }
    }

    fun generateSpeech(text: String, voiceName: String = "Kore") {
        if (text.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true
            _speechStatusMessage.value = "جاري معالجة الصوت بواسطة نموذج Gemini TTS..."

            val result = repository.generateSpeechTts(text, voiceName)
            result.onSuccess { msg ->
                _speechStatusMessage.value = msg
                val sessionId = _currentSessionId.value
                if (sessionId != null) {
                    repository.saveMessage(
                        sessionId = sessionId,
                        sender = "dji_ai",
                        content = "🔊 **تم توليد المقطع الصوتي بالنص:** \"$text\"\n\n$msg",
                        modelName = "gemini-2.5-flash-preview-tts"
                    )
                }
            }.onFailure { err ->
                _speechStatusMessage.value = "خطأ في معالجة الصوت: ${err.localizedMessage}"
            }
            _isLoading.value = false
        }
    }
}
