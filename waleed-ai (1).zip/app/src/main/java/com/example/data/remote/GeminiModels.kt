package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @field:Json(name = "contents") val contents: List<Content>,
    @field:Json(name = "generationConfig") val generationConfig: GenerationConfig? = null,
    @field:Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @field:Json(name = "parts") val parts: List<Part>,
    @field:Json(name = "role") val role: String? = null
)

@JsonClass(generateAdapter = true)
data class Part(
    @field:Json(name = "text") val text: String? = null,
    @field:Json(name = "inlineData") val inlineData: InlineData? = null
)

@JsonClass(generateAdapter = true)
data class InlineData(
    @field:Json(name = "mimeType") val mimeType: String,
    @field:Json(name = "data") val data: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    @field:Json(name = "temperature") val temperature: Float? = null,
    @field:Json(name = "topP") val topP: Float? = null,
    @field:Json(name = "topK") val topK: Int? = null,
    @field:Json(name = "thinkingConfig") val thinkingConfig: ThinkingConfig? = null,
    @field:Json(name = "imageConfig") val imageConfig: ImageConfig? = null,
    @field:Json(name = "speechConfig") val speechConfig: SpeechConfig? = null,
    @field:Json(name = "responseModalities") val responseModalities: List<String>? = null
)

@JsonClass(generateAdapter = true)
data class ThinkingConfig(
    @field:Json(name = "thinkingLevel") val thinkingLevel: String = "low"
)

@JsonClass(generateAdapter = true)
data class ImageConfig(
    @field:Json(name = "aspectRatio") val aspectRatio: String = "1:1",
    @field:Json(name = "imageSize") val imageSize: String = "1K"
)

@JsonClass(generateAdapter = true)
data class SpeechConfig(
    @field:Json(name = "voiceConfig") val voiceConfig: VoiceConfig
)

@JsonClass(generateAdapter = true)
data class VoiceConfig(
    @field:Json(name = "prebuiltVoiceConfig") val prebuiltVoiceConfig: PrebuiltVoiceConfig
)

@JsonClass(generateAdapter = true)
data class PrebuiltVoiceConfig(
    @field:Json(name = "voiceName") val voiceName: String = "Kore"
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    @field:Json(name = "candidates") val candidates: List<Candidate>? = null,
    @field:Json(name = "error") val error: ApiError? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @field:Json(name = "content") val content: Content? = null,
    @field:Json(name = "finishReason") val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class ApiError(
    @field:Json(name = "code") val code: Int? = null,
    @field:Json(name = "message") val message: String? = null,
    @field:Json(name = "status") val status: String? = null
)

@JsonClass(generateAdapter = true)
data class VeoGenerateRequest(
    @field:Json(name = "prompt") val prompt: String,
    @field:Json(name = "config") val config: VeoConfig? = null
)

@JsonClass(generateAdapter = true)
data class VeoConfig(
    @field:Json(name = "numberOfVideos") val numberOfVideos: Int = 1,
    @field:Json(name = "resolution") val resolution: String = "1080p",
    @field:Json(name = "aspectRatio") val aspectRatio: String = "16:9"
)
