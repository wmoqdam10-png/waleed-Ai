package com.example.data.repository

import com.example.BuildConfig
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.remote.Content
import com.example.data.remote.GenerateContentRequest
import com.example.data.remote.GenerationConfig
import com.example.data.remote.ImageConfig
import com.example.data.remote.InlineData
import com.example.data.remote.Part
import com.example.data.remote.PrebuiltVoiceConfig
import com.example.data.remote.RetrofitClient
import com.example.data.remote.SpeechConfig
import com.example.data.remote.ThinkingConfig
import com.example.data.remote.VoiceConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

data class DjiModelInfo(
    val id: String,
    val name: String,
    val description: String,
    val descriptionAr: String,
    val category: String, // "chat", "image", "audio", "video", "code"
    val badge: String,
    val isRecommended: Boolean = false
)

object DjiModelCatalog {
    val models = listOf(
        DjiModelInfo(
            id = "gemini-3.5-flash",
            name = "Gemini 3.5 Flash",
            description = "Fast, intelligent multimodal reasoning for general tasks & chat",
            descriptionAr = "نموذج الاستدلال السريع والأذكى للمحادثات اليومية المتقدمة",
            category = "chat",
            badge = "افتراضي",
            isRecommended = true
        ),
        DjiModelInfo(
            id = "gemini-3.1-pro-preview",
            name = "Gemini 3.1 Pro",
            description = "Advanced reasoning, deep logic, mathematics, and complex coding",
            descriptionAr = "النموذج الأقوى للمنطق المعقد، البرمجة البرمجية والتحليل العميق",
            category = "code",
            badge = "احترافي"
        ),
        DjiModelInfo(
            id = "gemini-3.1-flash-lite-preview",
            name = "Gemini 3.1 Flash Lite",
            description = "Ultra-fast lightweight model for instant answers and summary",
            descriptionAr = "نموذج خفيف وخارق السرعة للاستجابات الفورية والملخصات",
            category = "chat",
            badge = "سريع جداً"
        ),
        DjiModelInfo(
            id = "gemini-2.5-flash-image",
            name = "Gemini 2.5 Flash Image",
            description = "AI Image generation & visual design editor (Nano Banana)",
            descriptionAr = "استوديو نانو بنانا لتوليد وتصميم الصور الابتكارية",
            category = "image",
            badge = "صور"
        ),
        DjiModelInfo(
            id = "gemini-3.1-flash-image-preview",
            name = "Gemini 3.1 Flash Image HD",
            description = "High-definition image generation supporting 1K, 2K & 4K quality",
            descriptionAr = "توليد صور فائقة الجودة والدقة العالية مع تفاصيل دقيقة",
            category = "image",
            badge = "دقة 4K"
        ),
        DjiModelInfo(
            id = "gemini-2.5-flash-native-audio-preview-12-2025",
            name = "Gemini 2.5 Native Audio",
            description = "Real-time voice processing and audio understanding",
            descriptionAr = "معالجة الأصوات الحية والتفاعل الصوتي الذكي في الوقت الفعلي",
            category = "audio",
            badge = "صوتي حي"
        ),
        DjiModelInfo(
            id = "gemini-2.5-flash-preview-tts",
            name = "Gemini 2.5 Text-to-Speech",
            description = "Human-like TTS voice synthesis with multiple prebuilt voices",
            descriptionAr = "توليد نطق صوتي بشري طبيعي مع عدة أصوات عربية وعالمية",
            category = "audio",
            badge = "صوت بشري"
        ),
        DjiModelInfo(
            id = "veo-3.1-fast-generate-preview",
            name = "Veo 3.1 Video Studio",
            description = "Generative AI Video creation from descriptive text prompts",
            descriptionAr = "استوديو VEO 3.1 لتوليد مقاطع الفيديو الذكية السينمائية",
            category = "video",
            badge = "فيديو"
        )
    )

    fun getModelById(id: String): DjiModelInfo {
        return models.firstOrNull { it.id == id } ?: models.first()
    }
}

class DjiAiRepository(private val chatDao: ChatDao) {

    val allSessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()

    fun getSessionMessages(sessionId: Long): Flow<List<ChatMessageEntity>> {
        return chatDao.getMessagesForSession(sessionId)
    }

    suspend fun createNewSession(title: String, model: String, category: String = "chat"): Long {
        return chatDao.insertSession(
            ChatSessionEntity(
                title = title,
                selectedModel = model,
                category = category
            )
        )
    }

    suspend fun deleteSession(sessionId: Long) {
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteSession(sessionId)
    }

    suspend fun saveMessage(
        sessionId: Long,
        sender: String,
        content: String,
        modelName: String,
        imageUrl: String? = null,
        audioUrl: String? = null
    ): Long {
        return chatDao.insertMessage(
            ChatMessageEntity(
                sessionId = sessionId,
                sender = sender,
                content = content,
                modelName = modelName,
                imageUrl = imageUrl,
                audioUrl = audioUrl
            )
        )
    }

    suspend fun generateAiResponse(
        prompt: String,
        modelId: String,
        history: List<ChatMessageEntity> = emptyList(),
        systemInstructionText: String? = null,
        temperature: Float = 0.7f,
        thinkingLevel: String? = null,
        imageBase64: String? = null
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "⚠️ مفتاح API غير مهيأ بعد. يرجى إضافة GEMINI_API_KEY في لوحة الأسرار (Secrets Panel) لتفعيل الذكاء الاصطناعي."
        }

        val requestContents = mutableListOf<Content>()

        // Include history
        history.takeLast(10).forEach { msg ->
            val role = if (msg.sender == "user") "user" else "model"
            requestContents.add(
                Content(
                    parts = listOf(Part(text = msg.content)),
                    role = role
                )
            )
        }

        // Current prompt
        val currentParts = mutableListOf<Part>()
        currentParts.add(Part(text = prompt))
        if (!imageBase64.isNullOrEmpty()) {
            currentParts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = imageBase64)))
        }

        requestContents.add(Content(parts = currentParts, role = "user"))

        val thinkingConfig = if (thinkingLevel != null && thinkingLevel != "none") {
            ThinkingConfig(thinkingLevel = thinkingLevel)
        } else null

        val sysInstruction = if (!systemInstructionText.isNullOrBlank()) {
            Content(parts = listOf(Part(text = systemInstructionText)))
        } else null

        val request = GenerateContentRequest(
            contents = requestContents,
            generationConfig = GenerationConfig(
                temperature = temperature,
                thinkingConfig = thinkingConfig
            ),
            systemInstruction = sysInstruction
        )

        try {
            val response = RetrofitClient.apiService.generateContent(
                model = modelId,
                apiKey = apiKey,
                request = request
            )

            if (response.isSuccessful) {
                val body = response.body()
                val text = body?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                text ?: body?.error?.message ?: "لم يتم استلام أي نص من النموذج."
            } else {
                val errorMsg = response.errorBody()?.string() ?: response.message()
                "خطأ في الاتصال بالنموذج ($modelId): $errorMsg"
            }
        } catch (e: Exception) {
            "عذراً، حدث خطأ أثناء الاتصال بالشبكة: ${e.localizedMessage}"
        }
    }

    suspend fun generateImagePrompt(
        prompt: String,
        aspectRatio: String = "1:1",
        modelId: String = "gemini-2.5-flash-image"
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("مفتاح API غير مهيأ في لوحة الأسرار."))
        }

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                imageConfig = ImageConfig(aspectRatio = aspectRatio),
                responseModalities = listOf("TEXT", "IMAGE")
            )
        )

        try {
            val response = RetrofitClient.apiService.generateContent(
                model = modelId,
                apiKey = apiKey,
                request = request
            )
            if (response.isSuccessful) {
                val text = response.body()?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                Result.success(text ?: "تم توليد تصميم الصورة بنجاح!")
            } else {
                Result.failure(Exception("خطأ الخادم: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun generateSpeechTts(
        text: String,
        voiceName: String = "Kore"
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("مفتاح API غير مكتمل."))
        }

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = text)))),
            generationConfig = GenerationConfig(
                responseModalities = listOf("AUDIO"),
                speechConfig = SpeechConfig(
                    voiceConfig = VoiceConfig(
                        prebuiltVoiceConfig = PrebuiltVoiceConfig(voiceName = voiceName)
                    )
                )
            )
        )

        try {
            val response = RetrofitClient.apiService.generateContent(
                model = "gemini-2.5-flash-preview-tts",
                apiKey = apiKey,
                request = request
            )
            if (response.isSuccessful) {
                Result.success("تم تحويل النص إلى صوت بشرى بنجاح بنبرة الصوت ($voiceName)!")
            } else {
                Result.failure(Exception("خطأ في الخدمة: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
